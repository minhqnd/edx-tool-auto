const WORKER_URL = "https://edx.moimoi.workers.dev";

document.addEventListener('DOMContentLoaded', async () => {
  const licenseInput = document.getElementById('license-key');
  const activateBtn = document.getElementById('activate-btn');
  const btnSpinner = document.getElementById('btn-spinner');
  const btnText = document.getElementById('btn-text');
  const statusBox = document.getElementById('status-box');
  const statusText = document.getElementById('status-text');
  const infoUsername = document.getElementById('info-username');
  const infoCourse = document.getElementById('info-course');

  let activeTab = null;
  let username = null;
  let courseId = null;

  // 1. Get active tab
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs && tabs[0]) {
      activeTab = tabs[0];
    }
  } catch (e) {
    console.error("Failed to query active tab:", e);
  }

  if (!activeTab || (!activeTab.url.includes('learning.edx.org') && !activeTab.url.includes('courses.edx.org'))) {
    showStatus('Please open an edX course page first.', 'error');
    activateBtn.disabled = true;
    infoUsername.innerText = "No edX session";
    infoCourse.innerText = "No edX course";
    return;
  }

  // 2. Load stored license key
  chrome.storage.local.get(['edx_license_key'], (result) => {
    if (result.edx_license_key) {
      licenseInput.value = result.edx_license_key;
    }
  });

  // 3. Extract username and course ID from the active tab using executeScript
  showStatus('Detecting active edX session...', 'success');
  
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      func: extractPageData
    });

    if (results && results[0] && results[0].result) {
      const data = results[0].result;
      username = data.username;
      courseId = data.courseId;

      infoUsername.innerText = username || "Not logged in";
      infoCourse.innerText = data.courseName || (courseId ? courseId.split(':')[1]?.split('+')[0] || courseId : "Not in course");
      
      if (!username) {
        showStatus('Username not detected. Please login.', 'error');
        activateBtn.disabled = true;
      } else if (!courseId) {
        showStatus('Course not detected. Open a course page.', 'error');
        activateBtn.disabled = true;
      } else {
        showStatus('Session verified. Ready to sync.', 'success');
      }
    }
  } catch (err) {
    console.error("Script injection failed:", err);
    showStatus('Failed to scan edX page details.', 'error');
  }

  // 4. Activate button click handler
  activateBtn.addEventListener('click', async () => {
    const key = licenseInput.value.trim();
    if (!key) {
      showStatus('Please enter a license key.', 'error');
      return;
    }

    if (!username || !courseId) {
      showStatus('Session missing. Reload edX page.', 'error');
      return;
    }

    if (WORKER_URL === "YOUR_CLOUDFLARE_WORKER_URL") {
      showStatus('DRM Server URL not configured.', 'error');
      alert("Error: Cloudflare Worker URL is not configured. Please edit line 9 in popup.js.");
      return;
    }

    // Enter loading state
    activateBtn.disabled = true;
    btnSpinner.style.display = 'block';
    btnText.innerText = 'Verifying...';
    showStatus('Contacting DRM server...', 'success');

    // Clear and hide log box initially
    const logBox = document.getElementById('log-box');
    if (logBox) {
      logBox.innerHTML = '';
      logBox.style.display = 'none';
    }

    try {
      const response = await fetch(`${WORKER_URL}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: key, username })
      });

      const result = await response.json();

      if (response.ok && result.success) {
        if (!result.token) {
          showStatus('Server returned no execution token. Contact support.', 'error');
          resetButton();
          return;
        }
        showStatus('Authorized. Injecting syncer...', 'success');
        btnText.innerText = 'Syncing...';

        // Save key locally
        chrome.storage.local.set({ edx_license_key: key });

        // Forward the sync command with token to content script
        chrome.tabs.sendMessage(activeTab.id, {
          action: "EXECUTE_SYNC",
          username: username,
          expires: result.expires,
          token: result.token,
          workerUrl: WORKER_URL
        }, (response) => {
          if (chrome.runtime.lastError) {
            showStatus('Connection failed. Please refresh edX page.', 'error');
            resetButton();
          } else if (response && response.success) {
            showStatus('Sync started! Streaming progress...', 'success');
          } else {
            showStatus('Sync injection failed.', 'error');
            resetButton();
          }
        });
      } else {
        showStatus(result.error || 'Verification failed.', 'error');
        resetButton();
      }
    } catch (netErr) {
      console.error(netErr);
      showStatus('Network error. Can\'t connect to DRM server.', 'error');
      resetButton();
    }
  });

  // 5. Listen for progress logs and completion from the active tab content script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request || !request.action) return;

    if (request.action === "SYNC_LOG") {
      const logBox = document.getElementById('log-box');
      if (logBox) {
        logBox.style.display = 'block';
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        const item = document.createElement('div');
        item.className = 'log-item';
        item.innerHTML = `<span class="log-time">[${time}]</span>${request.text}`;
        logBox.appendChild(item);
        logBox.scrollTop = logBox.scrollHeight;
      }
    } else if (request.action === "SYNC_COMPLETE") {
      resetButton();
      if (request.success) {
        showStatus(`Course synced successfully! Refreshing...`, 'success');
        
        // Reload tab to show completion status on page, then close popup
        setTimeout(() => {
          if (activeTab && activeTab.id) {
            chrome.tabs.reload(activeTab.id);
          }
          window.close();
        }, 3000);
      } else {
        showStatus(request.error || 'Sync failed.', 'error');
      }
    }
  });

  function resetButton() {
    activateBtn.disabled = false;
    btnSpinner.style.display = 'none';
    btnText.innerText = 'Activate & Sync Course';
  }

  function showStatus(text, type) {
    statusBox.style.display = 'flex';
    statusBox.className = `status-area ${type}`;
    statusText.innerText = text;
  }
});

// This function runs directly inside the active edX webpage context
async function extractPageData() {
  // A. Robust username extraction
  function getUsername() {
    function decodeJwt(token) {
      try {
        const parts = token.split('.');
        if (parts.length === 3) {
          const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
          if (payload) return payload.username || payload.preferred_username;
        }
      } catch (e) {}
      return null;
    }

    for (const storage of [localStorage, sessionStorage]) {
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        const val = storage.getItem(key);
        if (!val) continue;
        const fromJwt = decodeJwt(val);
        if (fromJwt) return fromJwt;
        try {
          const parsed = JSON.parse(val);
          if (parsed && parsed.username) return parsed.username;
        } catch(e) {}
      }
    }

    const cookies = document.cookie.split('; ');
    for (const cookie of cookies) {
      const parts = cookie.split('=');
      const val = decodeURIComponent(parts.slice(1).join('='));
      const fromJwt = decodeJwt(val);
      if (fromJwt) return fromJwt;
      try {
        const clean = val.replace(/^"|"$/g, '').replace(/\\"/g, '"');
        const parsed = JSON.parse(clean);
        if (parsed && parsed.username) return parsed.username;
      } catch(e) {}
    }

    const uLinks = document.querySelectorAll('a[href*="/u/"]');
    for (const a of uLinks) {
      const href = a.getAttribute('href');
      const match = href.match(/\/u\/([^/?#\s]+)/);
      if (match && match[1]) {
        const u = match[1].trim();
        if (!['dashboard', 'home', 'courses', 'profile', 'account'].includes(u)) return u;
      }
    }
    
    if (window.USER && window.USER.username) return window.USER.username;
    return null;
  }

  // B. Robust course ID extraction
  function getCourseId() {
    let pathname = window.location.pathname;
    try {
      if (window.top && window.top.location) {
        pathname = window.top.location.pathname;
      }
    } catch (e) {}

    const pathMatch = pathname.match(/\/course\/([^/]+)/);
    if (pathMatch && pathMatch[1]) {
      let rawId = pathMatch[1];
      if (rawId.includes('+type@') || rawId.includes('+block@')) {
        const parts = rawId.split('+');
        if (parts.length >= 3) return parts.slice(0, 3).join('+');
      }
      return rawId;
    }

    const fullText = pathname + window.location.search + window.location.hash + document.documentElement.innerHTML;
    const modernMatch = fullText.match(/(course-v1:[^+/\s"']+\+[^+/\s"']+\+[^+/\s"']+)/);
    if (modernMatch && modernMatch[1]) return modernMatch[1];

    return document.body.getAttribute('data-course-id') || null;
  }

  // C. Robust course Name extraction (e.g. "IoT Sensors and Devices (T2 2018)")
  function getCourseName() {
    const courseId = getCourseId();
    let termSuffix = "";
    
    // Parse term/semester from courseId if available (e.g., "course-v1:CurtinX+IOT2x+2T2018" -> "T2 2018")
    if (courseId) {
      const parts = courseId.split(':');
      if (parts.length > 1) {
        const segments = parts[1].split('+');
        if (segments.length >= 3) {
          const rawTerm = segments[2];
          const termMatch = rawTerm.match(/^(\d+)T(\d{4})$/i);
          if (termMatch) {
            termSuffix = ` (T${termMatch[1]} ${termMatch[2]})`;
          } else {
            const termMatch2 = rawTerm.match(/^T(\d+)_(\d{4})$/i);
            if (termMatch2) {
              termSuffix = ` (T${termMatch2[1]} ${termMatch2[2]})`;
            } else {
              termSuffix = ` (${rawTerm})`;
            }
          }
        }
      }
    }

    function cleanTitle(title) {
      if (!title) return "";
      let t = title.trim();
      if (termSuffix) {
        const cleanTerm = termSuffix.replace(/[()]/g, '').trim();
        // Check if the title already contains the term/semester suffix (case-insensitive)
        if (t.toLowerCase().includes(cleanTerm.toLowerCase())) {
          return t;
        }
        // Check if the title already contains the raw term segment (e.g. "2T2018")
        if (courseId) {
          const parts = courseId.split(':');
          if (parts.length > 1) {
            const segments = parts[1].split('+');
            if (segments.length >= 3 && t.toLowerCase().includes(segments[2].toLowerCase())) {
              return t;
            }
          }
        }
      }
      return t + termSuffix;
    }

    // Selector Strategy: Query common edX elements for the course title
    const selectors = [
      '.course-header h1',
      '.course-title',
      '.course-name',
      '.course-title-link',
      'h1.course-title',
      '.course-sidebar-title',
      '.header-course-title',
      '.course-link'
    ];

    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent) {
        const title = el.textContent.trim();
        if (title.length > 3 && !title.toLowerCase().includes('outline') && !title.toLowerCase().includes('home')) {
          return cleanTitle(title);
        }
      }
    }

    // Breadcrumb Strategy
    const bcLinks = document.querySelectorAll('.breadcrumb-item a, [class*="breadcrumb"] a, .breadcrumbs a');
    for (const link of bcLinks) {
      const text = link.textContent.trim();
      if (text.length > 5 && !text.toLowerCase().includes('home') && !text.toLowerCase().includes('courses') && !text.toLowerCase().includes('dashboard')) {
        return cleanTitle(text);
      }
    }

    // Document Title Strategy (e.g. "IoT Sensors and Devices | edX" or "Course Outline | IoT Sensors and Devices | edX")
    if (document.title) {
      const titleParts = document.title.split('|').map(p => p.trim());
      const cleanParts = titleParts.filter(p => {
        const lp = p.toLowerCase();
        return lp !== 'edx' && lp !== 'learning' && lp !== 'course' && lp !== 'home' && lp !== 'outline' && lp !== 'progress' && lp !== 'dashboard';
      });
      if (cleanParts.length > 0) {
        cleanParts.sort((a, b) => b.length - a.length); // get the longest descriptive string
        if (cleanParts[0].length > 3) {
          return cleanTitle(cleanParts[0]);
        }
      }
    }

    // Ultimate Fallback: return formatted courseId if nothing else worked
    if (courseId) {
      const parts = courseId.split(':');
      if (parts.length > 1) {
        const segments = parts[1].split('+');
        if (segments.length >= 2) {
          return segments[1] + termSuffix;
        }
        return parts[1];
      }
    }

    return null;
  }

  // Fetch asynchronous /api/user/v1/me if synchronous checks failed
  let username = getUsername();
  if (!username) {
    try {
      const res = await fetch('https://courses.edx.org/api/user/v1/me', { credentials: 'include' });
      if (res.ok) {
        const data = await res.json();
        username = data.username;
      }
    } catch(e) {}
  }

  return {
    username,
    courseId: getCourseId(),
    courseName: getCourseName()
  };
}
